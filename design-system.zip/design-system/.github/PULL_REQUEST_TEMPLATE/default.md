---
name: Default pull request
about: Contribute to our project
title: ''
labels: ''
assignees: ''

---

## ☕ Purpose

A brief summary about the purpose of this PR.

## 🧐 Checklist

- [x] A feature that will work with this PR
- [ ] A feature that I'm still working on

## 🐞 Testing

A brief description about how the reviewer can test my PR.

~~~shell
# don't forget to insert cli commands
~~~

## 🍩 Further details

Anything that the reviewer should know before approving it.

## 🔗 Related PRs

This PR is related to some other PRs in different services, they are:
* [`project#PR_NUMBER`](https://)
