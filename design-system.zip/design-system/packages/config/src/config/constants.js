export const ROOT = 'root';
export const TICKETS = 'tickets';
export const ONE = 'one';
export const INCENTIVE = 'incentive';

export const ROOT_URL = 'https://pre-home.vercel.app';
export const TICKETS_URL = 'https://pwa-tickets.vercel.app';
export const ONE_URL = 'https://pwa-one.vercel.app';
export const INCENTIVE_URL = 'https://pwa-incentive.vercel.app';
