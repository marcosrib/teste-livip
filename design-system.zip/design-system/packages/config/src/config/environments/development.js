const configs = {};

export default configs;
