import development from './development';
import production from './production';

const environments = {
  development,
  production,
};

export default environments;
