import config from './livipConfig';

export default config;
