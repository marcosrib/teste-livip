export const MENU_TYPE_SUB = 'submenu';
export const MENU_TYPE_MAIN = 'mainmenu';

export const MENU_TYPES = [
  MENU_TYPE_SUB,
  MENU_TYPE_MAIN,
];

export const MENU_TYPE_DEFAULT = MENU_TYPE_SUB;
