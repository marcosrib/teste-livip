export const headerRef = 'app.header';
export const headerMenuRef = `${headerRef}.menu`;
