export const DEFAULT_MENU_STATE = false;
