import { FILTER_DEFAULT } from './constants';

const defaultProps = {
  defaultFilter: FILTER_DEFAULT,
  variant: 'event',
  columns: 3,
};

export default defaultProps;
