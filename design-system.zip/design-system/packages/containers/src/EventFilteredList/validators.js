export const isEventOnCategory = (event, category) => (
  event.categories.includes(category)
);
