export const FILTER_DEFAULT = 'todos';

export const EVENT_DEFAULT = {
  categories: [FILTER_DEFAULT],
};
