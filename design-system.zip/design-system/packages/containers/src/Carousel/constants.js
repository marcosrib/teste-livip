export const VARIANTS = {
  NAVIGATION_ON_RIGHT: 'navigation-on-right',
};
