const defaultProps = {
  play: true,
  stopOnHover: true,
  intervalInMilliseconds: 4000,
  customClasses: {},
};

export default defaultProps;
