import withStyles from '@livipdev/core/styles/withStyles';

import Footer from './Footer';
import styles from './styles';

export default withStyles(styles)(Footer);
