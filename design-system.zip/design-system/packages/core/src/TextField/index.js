import React from 'react';
import MuiTextField from '@material-ui/core/TextField';

const TextField = (props) => <MuiTextField {...props} />;

TextField.propTypes = MuiTextField.propTypes

export default TextField;
