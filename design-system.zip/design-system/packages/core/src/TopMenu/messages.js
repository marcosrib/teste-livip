import { headerMenuRef } from '@livipdev/containers/Header/messages';

export const topMenuRef = `${headerMenuRef}.top`;
