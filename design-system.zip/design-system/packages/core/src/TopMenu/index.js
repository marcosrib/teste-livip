import withStyles from '../styles/withStyles';

import styles from './styles';
import TopMenu from './TopMenu';

export default withStyles(styles)(TopMenu);
