import React from 'react';
import MuiList from '@material-ui/core/List';

const List = (props) => <MuiList {...props} />;

List.propTypes = MuiList.propTypes;

export default List;
