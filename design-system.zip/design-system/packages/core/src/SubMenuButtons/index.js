import withStyles from '../styles/withStyles';

import styles from './styles';
import SubMenuButtons from './SubMenuButtons';

export default withStyles(styles)(SubMenuButtons);
