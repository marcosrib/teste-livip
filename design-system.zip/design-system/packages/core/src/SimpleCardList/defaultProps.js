const defaultProps = {
  columns: 3,
};

export default defaultProps;
