import withStyles from '../styles/withStyles';

import styles from './styles';
import EventCardDetails from './EventCardDetails';

export default withStyles(styles)(EventCardDetails);
