const date = {
  weekday: 'long',
  day: '2-digit',
  month: 'long',
  hour: '2-digit',
};

const formats = {
  date,
};

const defaultProps = {
  formats,
};

export default defaultProps;
