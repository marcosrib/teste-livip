export default function () {
  return {
    address: {
      color: 'rgba(255, 255, 255, .5)',
      fontSize: '.75rem',
    },
  };
}
