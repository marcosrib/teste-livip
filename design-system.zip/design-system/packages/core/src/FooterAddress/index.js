import withStyles from '@livipdev/core/styles/withStyles';

import styles from './styles';
import FooterAddress from './FooterAddress';

export default withStyles(styles)(FooterAddress);
