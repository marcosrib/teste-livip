import withStyles from '../styles/withStyles';

import styles from './styles';
import TopMenuClaim from './TopMenuClaim';

export default withStyles(styles)(TopMenuClaim);
