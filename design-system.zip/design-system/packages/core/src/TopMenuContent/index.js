import withStyles from '../styles/withStyles';

import styles from './styles';
import TopMenuContent from './TopMenuContent';

export default withStyles(styles)(TopMenuContent);
