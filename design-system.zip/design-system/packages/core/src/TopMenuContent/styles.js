const styles = (theme) => ({
  root: {
    ...theme.alignments.center,
  },
});

export default styles;
