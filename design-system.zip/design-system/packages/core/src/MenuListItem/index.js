import withStyles from '../styles/withStyles';

import styles from './styles';
import MenuListItem from './MenuListItem';

export default withStyles(styles)(MenuListItem);
