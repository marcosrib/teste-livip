import PropTypes from 'prop-types';

const propTypes = {
  classes: PropTypes.object,
  height: PropTypes.number,
};

export default propTypes;
