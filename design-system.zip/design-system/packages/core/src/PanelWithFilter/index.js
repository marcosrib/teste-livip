import withStyles from '../styles/withStyles';

import styles from './styles';
import PanelWithFilter from './PanelWithFilter';

export default withStyles(styles)(PanelWithFilter);
