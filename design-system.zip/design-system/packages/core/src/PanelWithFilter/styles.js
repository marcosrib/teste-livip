const styles = (theme) => ({
  container: {
    paddingTop: theme.spaces.loose.value,
    paddingBottom: theme.spaces.loose.value,
  },
});

export default styles;
