const defaultProps = {
  maxWidth: 'false',
};

export default defaultProps;
