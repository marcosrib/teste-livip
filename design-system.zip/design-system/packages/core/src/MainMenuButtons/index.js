import withStyles from '../styles/withStyles';

import styles from './styles';
import MainMenuButtons from './MainMenuButtons';

export default withStyles(styles)(MainMenuButtons);
