import PropTypes from 'prop-types';

const propTypes = {
  classes: PropTypes.object,
  isExiting: PropTypes.bool,
};

export default propTypes;
