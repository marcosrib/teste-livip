const styles = {
  root: {
    flexGrow: 1,
  },
};

export default styles;
