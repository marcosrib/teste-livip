import withStyles from '@livipdev/core/styles/withStyles';

import styles from './styles';
import Spacer from './Spacer';

export default withStyles(styles)(Spacer);
