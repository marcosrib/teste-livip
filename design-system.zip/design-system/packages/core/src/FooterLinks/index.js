import withStyles from '@livipdev/core/styles/withStyles';

import styles from './styles';
import FooterLinks from './FooterLinks';

export default withStyles(styles)(FooterLinks);
