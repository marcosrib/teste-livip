export default function (theme) {
  return {
    link: {
      display: 'block',
      textDecoration: 'none',
      marginBottom: `${theme.spacing(2)}px`,
    },
  };
}
