export default function () {
  return {};
}
