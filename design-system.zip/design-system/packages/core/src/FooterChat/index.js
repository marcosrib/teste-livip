import withStyles from '@livipdev/core/styles/withStyles';

import styles from './styles';
import FooterChat from './FooterChat';

export default withStyles(styles)(FooterChat);
