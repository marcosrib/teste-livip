import withStyles from '../styles/withStyles';

import styles from './styles';
import ContainerWithBackground from './ContainerWithBackground';

export default withStyles(styles)(ContainerWithBackground);
