import withStyles from '../styles/withStyles';

import styles from './styles';
import SocialIcons from './SocialIcons';

export default withStyles(styles)(SocialIcons);
