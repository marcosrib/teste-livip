import React from 'react';
import MuiTab from '@material-ui/core/Tab';

const Tab = (props) => <MuiTab {...props} />;

Tab.propTypes = MuiTab.propTypes

export default Tab;
