import withStyles from '../styles/withStyles';

import styles from './styles';
import MenuLink from './MenuLink';

export default withStyles(styles)(MenuLink);
