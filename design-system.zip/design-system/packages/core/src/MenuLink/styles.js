const styles = (theme) => ({
  root: {
    ...theme.typography.menu.root,
    color: theme.palette.common.white,
  },
});

export default styles;
