import PropTypes from 'prop-types';

const propTypes = {
  classes: PropTypes.object,
  href: PropTypes.string,
};

export default propTypes;
