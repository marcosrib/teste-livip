export const ID = '$ID';

export const WHATSAPP_HREF = `whatsapp://send?text=Lorem ipsum dolor https://livip.com.br/eventos/${ID}`;
export const WHATSAPP_DATA_ACTION = 'share/whatsapp/share';

export const EMAIL_HREF = `mailto:?subject=Lorem Ipsum&amp;body=Lorem ipsim dolor https://livip.com.br/eventos/${ID}`;

export const TWITTER_HREF = `http://twitter.com/share?text=Lorem ipsum dolor https://livip.com.br/eventos/${ID}`;
