import withStyles from '../styles/withStyles';

import styles from './styles';
import EventCardShare from './EventCardShare';

export default withStyles(styles)(EventCardShare);
