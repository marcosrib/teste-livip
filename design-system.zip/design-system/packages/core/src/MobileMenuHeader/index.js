import withStyles from '../styles/withStyles';

import styles from './styles';
import MobileMenuHeader from './MobileMenuHeader';

export default withStyles(styles)(MobileMenuHeader);
