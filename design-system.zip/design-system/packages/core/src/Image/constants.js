import { SCREEN_SIZES } from '../styles/theme/constants';

export const DEFAULT_VIEWPORT = SCREEN_SIZES.LARGE;
