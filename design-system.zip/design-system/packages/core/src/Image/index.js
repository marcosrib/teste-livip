import withStyles from '../styles/withStyles';

import styles from './styles';
import Image from './Image';

export default withStyles(styles)(Image);
