import withStyles from '../styles/withStyles';

import styles from './styles';
import HeaderMenu from './HeaderMenu';

export default withStyles(styles)(HeaderMenu);
