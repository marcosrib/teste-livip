const styles = {
  root: {
    paddingTop: 0,
    paddingBottom: 0,

    '&:last-child': {
      paddingBottom: 0,
    },
  },
};

export default styles;
