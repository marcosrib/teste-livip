import withStyles from '../styles/withStyles';

import styles from './styles';
import CardContent from './CardContent';

export default withStyles(styles)(CardContent);
