import PropTypes from 'prop-types';

const propTypes = {
  classes: PropTypes.obj,
};

export default propTypes;
