import PropTypes from 'prop-types';

const propTypes = {
  gutterX: PropTypes.number,
};

export default propTypes;
