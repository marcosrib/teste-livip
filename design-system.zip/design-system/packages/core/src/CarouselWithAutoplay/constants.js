export const BULLET_SIZE = 10;
