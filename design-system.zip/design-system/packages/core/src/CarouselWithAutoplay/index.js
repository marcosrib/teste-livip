import withStyles from '../styles/withStyles';

import styles from './styles';
import CarouselWithAutoplay from './CarouselWithAutoplay';

export default withStyles(styles)(CarouselWithAutoplay);
