import React from 'react';

import Grid from '../Grid';

const Gutter = (props) => <Grid item {...props} />;

export default Gutter;
