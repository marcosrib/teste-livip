import withStyles from '../styles/withStyles';

import styles from './styles';
import CssBaseline from './CssBaseline';

export default withStyles(styles)(CssBaseline);
