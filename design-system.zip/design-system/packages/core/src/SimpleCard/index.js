import withStyles from '../styles/withStyles';

import styles from './styles';
import SimpleCard from './SimpleCard';

export default withStyles(styles)(SimpleCard);
