import PropTypes from 'prop-types';

const propTypes = {
  categories: PropTypes.arrayOf(PropTypes.string),
};

export default propTypes;
