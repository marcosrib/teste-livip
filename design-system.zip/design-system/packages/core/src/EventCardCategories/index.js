import withStyles from '../styles/withStyles';

import styles from './styles';
import EventCardCategories from './EventCardCategories';

export default withStyles(styles)(EventCardCategories);
