const defaultProps = {
  href: '#',
};

export default defaultProps;
