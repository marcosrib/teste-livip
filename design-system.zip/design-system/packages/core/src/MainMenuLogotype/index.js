import withStyles from '../styles/withStyles';

import styles from './styles';
import MainMenuLogotype from './MainMenuLogotype';

export default withStyles(styles)(MainMenuLogotype);
