const defaultProps = {
  columns: 4,
  spacingType: 'default',
  cellHeight: 'auto',
};

export default defaultProps;
