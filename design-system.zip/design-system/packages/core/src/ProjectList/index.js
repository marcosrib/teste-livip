import withStyles from '@livipdev/core/styles/withStyles';

import styles from './styles';
import ProjectList from './ProjectList';

export default withStyles(styles)(ProjectList);
