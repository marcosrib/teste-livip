import React from 'react';
import MuiGridList from '@material-ui/core/GridList';

const GridList = (props) => <MuiGridList {...props} />;

GridList.propTypes = MuiGridList.propTypes;

export default GridList;
