import React from 'react';
import MuiTabs from '@material-ui/core/Tabs';

const Tabs = (props) => <MuiTabs {...props} />;

Tabs.propTypes = MuiTabs.propTypes

export default Tabs;
