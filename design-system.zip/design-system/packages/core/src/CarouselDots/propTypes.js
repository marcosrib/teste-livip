import PropTypes from 'prop-types';

const propTypes = {
  inverse: PropTypes.bool,
  customClass: PropTypes.string,
};

export default propTypes;
