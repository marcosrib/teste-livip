import withStyles from '../styles/withStyles';

import styles from './styles';
import CarouselDots from './CarouselDots';

export default withStyles(styles)(CarouselDots);
