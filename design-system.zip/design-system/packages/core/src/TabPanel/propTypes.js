import PropTypes from 'prop-types';

const propTypes = {
  children: PropTypes.node.isRequired,
};

export default propTypes;
