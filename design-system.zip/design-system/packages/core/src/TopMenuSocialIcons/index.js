import withStyles from '../styles/withStyles';

import styles from './styles';
import TopMenuSocialIcons from './TopMenuSocialIcons';

export default withStyles(styles)(TopMenuSocialIcons);
