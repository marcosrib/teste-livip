const styles = (theme) => ({
  root: {
    ...theme.alignments.autoMarginLeft,
  },
});

export default styles;
