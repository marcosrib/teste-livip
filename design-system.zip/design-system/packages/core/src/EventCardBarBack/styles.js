const styles = (theme) => ({
  grid: {
    ...theme.cards.bar.default,
  },
});

export default styles;
