import withStyles from '../styles/withStyles';

import styles from './styles';
import EventCardBarBack from './EventCardBarBack';

export default withStyles(styles)(EventCardBarBack);
