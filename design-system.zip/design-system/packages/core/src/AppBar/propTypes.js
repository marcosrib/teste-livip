import PropTypes from 'prop-types';

const propTypes = {
  classes: PropTypes.object,
};

export default propTypes;
