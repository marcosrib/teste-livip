import withStyles from '../styles/withStyles';

import styles from './styles';
import AppBar from './AppBar';

export default withStyles(styles)(AppBar);
