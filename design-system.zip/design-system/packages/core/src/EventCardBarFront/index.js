import withStyles from '../styles/withStyles';

import styles from './styles';
import EventCardBarFront from './EventCardBarFront';

export default withStyles(styles)(EventCardBarFront);
