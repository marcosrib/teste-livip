const styles = (theme) => ({
  box: {
    ...theme.cards.bar.default,
  },
});

export default styles;
