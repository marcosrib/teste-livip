import React, { Fragment } from 'react';

const CarouselSlide = ({ children }) => (
  <Fragment>
    {children}
  </Fragment>
);

export default CarouselSlide;
