import withStyles from '../styles/withStyles';

import styles from './styles';
import EventCardTitle from './EventCardTitle';

export default withStyles(styles)(EventCardTitle);
