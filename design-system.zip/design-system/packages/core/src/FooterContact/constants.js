export const PHONE = '+55 11 96345 8082';
export const EMAIL = 'atendimento@livip.com.br';
