export const DEFAULT_ANIMATION = true;
