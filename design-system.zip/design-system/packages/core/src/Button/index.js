import withStyles from '../styles/withStyles';

import styles from './styles';
import Button from './Button';

export default withStyles(styles)(Button);
