import withStyles from '../styles/withStyles';

import styles from './styles';
import EventCard from './EventCard';

export default withStyles(styles)(EventCard);
