import withStyles from '@livipdev/core/styles/withStyles';

import styles from './styles';
import Dialog from './Dialog';

export default withStyles(styles)(Dialog);
