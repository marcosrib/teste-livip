import withStyles from '../styles/withStyles';

import styles from './styles';
import HeaderMenuToggler from './HeaderMenuToggler';

export default withStyles(styles)(HeaderMenuToggler);
