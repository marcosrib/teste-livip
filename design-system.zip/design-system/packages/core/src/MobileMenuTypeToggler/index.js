import withStyles from '../styles/withStyles';

import styles from './styles';
import MobileMenuTypeToggler from './MobileMenuTypeToggler';

export default withStyles(styles)(MobileMenuTypeToggler);
