export const SELECTOR = 'min-width';
