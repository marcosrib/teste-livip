export const VARIANTS = {
  ALIGNED_TO_LEFT: 'aligned-to-left',
};
