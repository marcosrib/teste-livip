import withStyles from '../styles/withStyles';

import styles from './styles';
import CarouselSlideContent from './CarouselSlideContent';

export default withStyles(styles)(CarouselSlideContent);
