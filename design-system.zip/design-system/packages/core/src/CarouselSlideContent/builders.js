export const buildMessage = (message, variant) => ({
  variant,
  message,
});
