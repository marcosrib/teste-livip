import withStyles from '../styles/withStyles';

import styles from './styles';
import HeaderDrawer from './HeaderDrawer';

export default withStyles(styles)(HeaderDrawer);
