const defaultProps = {
  anchor: 'left',
};

export default defaultProps;
