import PropTypes from 'prop-types';

const propTypes = {
  classes: PropTypes.object,
  topGutter: PropTypes.number,
};

export default propTypes;
