import React from 'react';
import MuiCard from '@material-ui/core/Card';

const Card = (props) => <MuiCard {...props} />;

Card.propTypes = MuiCard.propTypes;

export default Card;
