import PropTypes from 'prop-types';

const propTypes = {
  toggleSide: PropTypes.func,
  classes: PropTypes.obj,
};

export default propTypes;
