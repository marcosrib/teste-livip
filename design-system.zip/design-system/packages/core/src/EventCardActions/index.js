import withStyles from '../styles/withStyles';

import styles from './styles';
import EventCardActions from './EventCardActions';

export default withStyles(styles)(EventCardActions);
