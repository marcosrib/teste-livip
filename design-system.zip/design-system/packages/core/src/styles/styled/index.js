import muiStyled from '@material-ui/core/styles/styled';

const styled = muiStyled;

export default styled;
