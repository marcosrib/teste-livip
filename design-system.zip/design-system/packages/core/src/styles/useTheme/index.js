import muiUseTheme from '@material-ui/core/styles/useTheme';

const useTheme = muiUseTheme;

export default useTheme;
