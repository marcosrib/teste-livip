import createMuiTheme from '@material-ui/core/styles/createMuiTheme';

import theme from './theme';

export default createMuiTheme(theme);
