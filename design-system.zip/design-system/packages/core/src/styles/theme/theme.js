import tokens from '@livipdev/tokens';

const theme = {
  ...tokens,
};

export default theme;
