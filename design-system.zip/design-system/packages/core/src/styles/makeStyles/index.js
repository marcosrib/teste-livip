import muiMakeStyles from '@material-ui/core/styles/makeStyles';

const makeStyles = muiMakeStyles;

export default makeStyles;
