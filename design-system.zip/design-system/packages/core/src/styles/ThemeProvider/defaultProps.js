const defaultProps = {
  muiProps: {},
};

export default defaultProps;
