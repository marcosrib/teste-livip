import { ServerStyleSheets } from '@material-ui/core/styles';

export default ServerStyleSheets;
