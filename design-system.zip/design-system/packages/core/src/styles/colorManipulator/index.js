import { fade as muiFade } from '@material-ui/core/styles/colorManipulator';

export const fade = muiFade;
