import muiWithStyles from '@material-ui/core/styles/withStyles';

const withStyles = muiWithStyles;

export default withStyles;
