import withStyles from '../styles/withStyles';

import styles from './styles';
import EventCardLocation from './EventCardLocation';

export default withStyles(styles)(EventCardLocation);
