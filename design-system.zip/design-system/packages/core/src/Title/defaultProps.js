const defaultProps = {
  maxWidth: 'false',
  subtitle: {},
  suptitle: {},
};

export default defaultProps;
