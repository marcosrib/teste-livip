const styles = (theme) => ({
  root: {
    marginBottom: ({ marginBottom }) => marginBottom,
  },
});

export default styles;
