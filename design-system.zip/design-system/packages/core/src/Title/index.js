import withStyles from '../styles/withStyles';

import styles from './styles';
import Title from './Title';

export default withStyles(styles)(Title);
