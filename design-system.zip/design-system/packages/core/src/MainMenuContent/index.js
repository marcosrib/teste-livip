import withStyles from '../styles/withStyles';

import styles from './styles';
import MainMenuContent from './MainMenuContent';

export default withStyles(styles)(MainMenuContent);
