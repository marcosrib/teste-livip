import config from '@livipdev/config';

const TICKETS = config.variants.tickets;
const ONE = config.variants.one;
const INCENTIVE = config.variants.incentive;
const ABOUT = 'about';
const CONTACT = 'contact';

export const MAIN_MENU_HASHMAP = {
  [TICKETS]: {
    key: 'tickets',
    href: '#',
  },
  [ONE]: {
    key: 'one',
    href: '#',
  },
  [INCENTIVE]: {
    key: 'incentive',
    href: 'https://livip2.onrender.com/',
  },
  [ABOUT]: {
    key: 'about',
    href: '#',
  },
  [CONTACT]: {
    key: 'contact',
    href: '#',
  },
};

export const MAIN_MENU_ORDER = [
  TICKETS,
  ONE,
  INCENTIVE,
];
