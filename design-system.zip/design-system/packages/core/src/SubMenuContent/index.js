import withStyles from '../styles/withStyles';

import styles from './styles';
import SubMenuContent from './SubMenuContent';

export default withStyles(styles)(SubMenuContent);
