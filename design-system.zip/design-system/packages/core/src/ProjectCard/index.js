import withStyles from '@livipdev/core/styles/withStyles';

import styles from './styles';
import ProjectCard from './ProjectCard';

export default withStyles(styles)(ProjectCard);
