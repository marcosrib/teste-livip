import withStyles from '../styles/withStyles';

import styles from './styles';
import HeaderToolbar from './HeaderToolbar';

export default withStyles(styles)(HeaderToolbar);
