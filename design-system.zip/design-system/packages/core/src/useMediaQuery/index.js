import muiUseMediaQuery from '@material-ui/core/useMediaQuery';

const useMediaQuery = muiUseMediaQuery;

export default useMediaQuery;
