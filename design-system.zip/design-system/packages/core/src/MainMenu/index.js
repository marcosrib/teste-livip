import withStyles from '../styles/withStyles';

import styles from './styles';
import MainMenu from './MainMenu';

export default withStyles(styles)(MainMenu);
