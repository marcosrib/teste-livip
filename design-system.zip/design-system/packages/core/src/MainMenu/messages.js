import { headerMenuRef } from '@livipdev/containers/Header/messages';

export const mainMenuRef = `${headerMenuRef}.main`;
