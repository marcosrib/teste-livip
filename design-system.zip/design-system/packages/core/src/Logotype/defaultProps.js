import { DEFAULT_VARIANT } from './constants';

const defaultProps = {
  variant: DEFAULT_VARIANT,
  viewBox: '0 0 143 26',
};

export default defaultProps;
