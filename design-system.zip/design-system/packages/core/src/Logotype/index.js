import withStyles from '../styles/withStyles';

import styles from './styles';
import Logotype from './Logotype';

export default withStyles(styles)(Logotype);
