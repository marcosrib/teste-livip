import withStyles from '../styles/withStyles';

import styles from './styles';
import EventList from './EventList';

export default withStyles(styles)(EventList);
