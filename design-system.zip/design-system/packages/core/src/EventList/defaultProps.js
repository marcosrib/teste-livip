const defaultProps = {
  columns: 3,
  spacingType: 'default',
  cellHeight: 'auto',
};

export default defaultProps;
