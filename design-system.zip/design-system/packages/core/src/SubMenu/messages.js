import { headerMenuRef } from '@livipdev/containers/Header/messages';

export const subMenuRef = `${headerMenuRef}.sub`;
