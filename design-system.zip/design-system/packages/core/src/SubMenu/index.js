import withStyles from '../styles/withStyles';

import styles from './styles';
import SubMenu from './SubMenu';

export default withStyles(styles)(SubMenu);
