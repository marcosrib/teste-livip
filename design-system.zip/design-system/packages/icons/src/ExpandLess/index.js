import React from 'react';
import MuiExpandLess from '@material-ui/icons/ExpandLess';

const ExpandLess = (props) => <MuiExpandLess {...props} />;

export default ExpandLess;
