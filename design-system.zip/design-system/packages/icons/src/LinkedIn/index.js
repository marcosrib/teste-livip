import React from 'react';
import MuiLinkedIn from '@material-ui/icons/LinkedIn';

const LinkedIn = (props) => <MuiLinkedIn {...props} />;

export default LinkedIn;
