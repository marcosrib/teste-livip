import React from 'react';
import MuiTwitter from '@material-ui/icons/Twitter';

const Twitter = (props) => <MuiTwitter {...props} />;

export default Twitter;
