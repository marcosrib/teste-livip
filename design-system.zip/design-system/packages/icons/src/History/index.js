import React from 'react';
import MuiHistory from '@material-ui/icons/History';

const History = (props) => <MuiHistory {...props} />;

export default History;
