import React from 'react';
import MuiWhatsApp from '@material-ui/icons/WhatsApp';

const WhatsApp = (props) => <MuiWhatsApp {...props} />;

export default WhatsApp;
