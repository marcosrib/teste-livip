import React from 'react';
import MuiMenu from '@material-ui/icons/Menu';

const Menu = (props) => <MuiMenu {...props} />;

export default Menu;
