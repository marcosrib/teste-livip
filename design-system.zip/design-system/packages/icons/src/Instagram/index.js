import React from 'react';
import MuiInstagram from '@material-ui/icons/Instagram';

const Instagram = (props) => <MuiInstagram {...props} />;

export default Instagram;
