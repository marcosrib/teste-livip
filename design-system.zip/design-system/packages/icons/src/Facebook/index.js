import React from 'react';
import MuiFacebook from '@material-ui/icons/Facebook';

const Facebook = (props) => <MuiFacebook {...props} />;

export default Facebook;
