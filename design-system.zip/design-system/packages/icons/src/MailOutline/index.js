import React from 'react';
import MuiMailOutline from '@material-ui/icons/MailOutline';

const MailOutline = (props) => <MuiMailOutline {...props} />;

export default MailOutline;
