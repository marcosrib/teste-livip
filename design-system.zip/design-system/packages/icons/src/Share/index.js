import React from 'react';
import MuiShare from '@material-ui/icons/Share';

const Share = (props) => <MuiShare {...props} />;

export default Share;
